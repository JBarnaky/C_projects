// dllmain.h : Declaration of module class.

class CGraphModule : public ATL::CAtlDllModuleT< CGraphModule >
{
public :
	DECLARE_LIBID(LIBID_GraphLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_GRAPH, "{77094083-A1E0-48DA-8B46-970792929513}")
};

extern class CGraphModule _AtlModule;
