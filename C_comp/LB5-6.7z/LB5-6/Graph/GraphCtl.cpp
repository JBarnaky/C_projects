// GraphCtl.cpp : Implementation of CGraphCtl
#include "stdafx.h"
#include "GraphCtl.h"


// CGraphCtl


STDMETHODIMP CGraphCtl::get_MinX(SHORT* pVal)
{
	*pVal = m_nMinX;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_MinX(SHORT newVal)
{
	m_nMinX = newVal;
	FireViewChange();

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_MinY(SHORT* pVal)
{
	*pVal = m_nMinY;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_MinY(SHORT newVal)
{
	m_nMinY = newVal;
	FireViewChange();

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_MaxX(SHORT* pVal)
{
	*pVal = m_nMaxX;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_MaxX(SHORT newVal)
{
	m_nMaxX = newVal;
	FireViewChange();

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_MaxY(SHORT* pVal)
{
	*pVal = m_nMaxY;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_MaxY(SHORT newVal)
{
	m_nMaxY = newVal;
	FireViewChange();

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_BackColor(OLE_COLOR* pVal)
{
	*pVal = m_clrBackColor;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_BackColor(OLE_COLOR newVal)
{
	m_clrBackColor = newVal;
	FireViewChange();

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_GraphColor(OLE_COLOR* pVal)
{
	*pVal = m_clrGraphColor;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_GraphColor(OLE_COLOR newVal)
{
	m_clrGraphColor = newVal;
	m_clrGraphColorOld = m_clrGraphColor;
	FireViewChange();

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_IsLButtonClicked(SHORT* pVal)
{
	*pVal = m_nIsLButtonClicked;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_IsLButtonClicked(SHORT newVal)
{
	if (m_nIsLButtonClicked == 1 && newVal == 1)
		return Error(_T("LButton is already clicked"));	
	
	m_nIsLButtonClicked = newVal;

	if (m_nIsLButtonClicked == 1)
	{
		m_nIsRButtonClicked = 0;
		m_clrGraphColor = m_clrGraphColorOld;
		FireViewChange();
	}

	return S_OK;
}


STDMETHODIMP CGraphCtl::get_IsRButtonClicked(SHORT* pVal)
{
	*pVal = m_nIsRButtonClicked;

	return S_OK;
}


STDMETHODIMP CGraphCtl::put_IsRButtonClicked(SHORT newVal)
{
	if (m_nIsRButtonClicked == 1 && newVal == 1)
		return Error(_T("RButton is already clicked"));

	m_nIsRButtonClicked = newVal;
	if (m_nIsRButtonClicked = 1)
	{
		m_nIsLButtonClicked = 0;
		m_clrGraphColor = m_clrBackColor;
		FireViewChange();
	}

	return S_OK;
}


LRESULT CGraphCtl::OnLButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	put_IsLButtonClicked(1);
	Fire_LClick();

	return 0;
}


LRESULT CGraphCtl::OnRButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	put_IsRButtonClicked(1);
	Fire_RClick();

	return 0;
}
