﻿Public Class Form1
    Dim _obj = CreateObject("MSCAL.Calendar.15")
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Bt_Set.Click
        _obj.Day = txtOp1.Text
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        txtOp2.Text = _obj.Day
    End Sub

   
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        _obj.Year = TextBox3.Text
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        TextBox2.Text = _obj.Year
    End Sub
End Class