// GraficCtl.cpp : Implementation of CGraficCtl
#include "stdafx.h"
#include "GraficCtl.h"


// CGraficCtl


STDMETHODIMP CGraficCtl::get_MinX(SHORT* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_nMinX;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_MinX(SHORT newVal)
{
	// TODO: Add your implementation code here
	m_nMinX = newVal;
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_MinY(SHORT* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_nMinY;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_MinY(SHORT newVal)
{
	// TODO: Add your implementation code here
	m_nMinY = newVal;
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_MaxX(SHORT* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_nMaxX;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_MaxX(SHORT newVal)
{
	// TODO: Add your implementation code here
	m_nMaxX = newVal;
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_MaxY(SHORT* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_nMaxY;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_MaxY(SHORT newVal)
{
	// TODO: Add your implementation code here
	m_nMaxY = newVal;
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_BackColor(OLE_COLOR* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_clrBackColor;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_BackColor(OLE_COLOR newVal)
{
	// TODO: Add your implementation code here
	m_clrBackColor = newVal;
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_GraficColor(OLE_COLOR* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_clrGraphColor;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_GraficColor(OLE_COLOR newVal)
{
	// TODO: Add your implementation code here
	m_clrGraphColor = newVal;
	m_clrGraphColorOld = m_clrGraphColor;
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_IsLButtonClicked(SHORT* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_nIsLButtonClicked;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_IsLButtonClicked(SHORT newVal)
{
	// TODO: Add your implementation code here
	if (m_nIsLButtonClicked == 1 && newVal == 1)
		return Error(_T("LButton is already clicked"));	
	
	m_nIsLButtonClicked = newVal;

	if (m_nIsLButtonClicked == 1)
	{
		m_nIsRButtonClicked = 0;
		m_clrGraphColor = m_clrGraphColorOld;
		FireViewChange();
	}
	return S_OK;
}


STDMETHODIMP CGraficCtl::get_IsRButtonClicked(SHORT* pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_nIsRButtonClicked;
	return S_OK;
}


STDMETHODIMP CGraficCtl::put_IsRButtonClicked(SHORT newVal)
{
	// TODO: Add your implementation code here
	if (m_nIsRButtonClicked == 1 && newVal == 1)
		return Error(_T("RButton is already clicked"));

	m_nIsRButtonClicked = newVal;
	if (m_nIsRButtonClicked = 1)
	{
		m_nIsLButtonClicked = 0;
		m_clrGraphColor = m_clrBackColor;
		FireViewChange();
	}
	return S_OK;
}


LRESULT CGraficCtl::OnLButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	// TODO: Add your message handler code here and/or call default
	put_IsLButtonClicked(1);
	Fire_LClick();
	return 0;
}


LRESULT CGraficCtl::OnRButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	// TODO: Add your message handler code here and/or call default
	put_IsRButtonClicked(1);
	Fire_RClick();
	return 0;
}
