

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Tue Dec 05 10:28:00 2017
 */
/* Compiler settings for Grafic.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Grafic_i_h__
#define __Grafic_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IGraficCtl_FWD_DEFINED__
#define __IGraficCtl_FWD_DEFINED__
typedef interface IGraficCtl IGraficCtl;
#endif 	/* __IGraficCtl_FWD_DEFINED__ */


#ifndef ___IGraficCtlEvents_FWD_DEFINED__
#define ___IGraficCtlEvents_FWD_DEFINED__
typedef interface _IGraficCtlEvents _IGraficCtlEvents;
#endif 	/* ___IGraficCtlEvents_FWD_DEFINED__ */


#ifndef __GraficCtl_FWD_DEFINED__
#define __GraficCtl_FWD_DEFINED__

#ifdef __cplusplus
typedef class GraficCtl GraficCtl;
#else
typedef struct GraficCtl GraficCtl;
#endif /* __cplusplus */

#endif 	/* __GraficCtl_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IGraficCtl_INTERFACE_DEFINED__
#define __IGraficCtl_INTERFACE_DEFINED__

/* interface IGraficCtl */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IGraficCtl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5449BD67-9C67-4ACF-87DE-247EF7182755")
    IGraficCtl : public IDispatch
    {
    public:
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_MinX( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_MinX( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_MinY( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_MinY( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_MaxX( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_MaxX( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_MaxY( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_MaxY( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_BackColor( 
            /* [retval][out] */ OLE_COLOR *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_BackColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_GraficColor( 
            /* [retval][out] */ OLE_COLOR *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_GraficColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_IsLButtonClicked( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_IsLButtonClicked( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_IsRButtonClicked( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_IsRButtonClicked( 
            /* [in] */ SHORT newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IGraficCtlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IGraficCtl * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IGraficCtl * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IGraficCtl * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IGraficCtl * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IGraficCtl * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IGraficCtl * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IGraficCtl * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MinX )( 
            IGraficCtl * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MinX )( 
            IGraficCtl * This,
            /* [in] */ SHORT newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MinY )( 
            IGraficCtl * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MinY )( 
            IGraficCtl * This,
            /* [in] */ SHORT newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MaxX )( 
            IGraficCtl * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MaxX )( 
            IGraficCtl * This,
            /* [in] */ SHORT newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_MaxY )( 
            IGraficCtl * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_MaxY )( 
            IGraficCtl * This,
            /* [in] */ SHORT newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_BackColor )( 
            IGraficCtl * This,
            /* [retval][out] */ OLE_COLOR *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_BackColor )( 
            IGraficCtl * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_GraficColor )( 
            IGraficCtl * This,
            /* [retval][out] */ OLE_COLOR *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_GraficColor )( 
            IGraficCtl * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_IsLButtonClicked )( 
            IGraficCtl * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_IsLButtonClicked )( 
            IGraficCtl * This,
            /* [in] */ SHORT newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_IsRButtonClicked )( 
            IGraficCtl * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_IsRButtonClicked )( 
            IGraficCtl * This,
            /* [in] */ SHORT newVal);
        
        END_INTERFACE
    } IGraficCtlVtbl;

    interface IGraficCtl
    {
        CONST_VTBL struct IGraficCtlVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IGraficCtl_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IGraficCtl_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IGraficCtl_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IGraficCtl_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IGraficCtl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IGraficCtl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IGraficCtl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IGraficCtl_get_MinX(This,pVal)	\
    ( (This)->lpVtbl -> get_MinX(This,pVal) ) 

#define IGraficCtl_put_MinX(This,newVal)	\
    ( (This)->lpVtbl -> put_MinX(This,newVal) ) 

#define IGraficCtl_get_MinY(This,pVal)	\
    ( (This)->lpVtbl -> get_MinY(This,pVal) ) 

#define IGraficCtl_put_MinY(This,newVal)	\
    ( (This)->lpVtbl -> put_MinY(This,newVal) ) 

#define IGraficCtl_get_MaxX(This,pVal)	\
    ( (This)->lpVtbl -> get_MaxX(This,pVal) ) 

#define IGraficCtl_put_MaxX(This,newVal)	\
    ( (This)->lpVtbl -> put_MaxX(This,newVal) ) 

#define IGraficCtl_get_MaxY(This,pVal)	\
    ( (This)->lpVtbl -> get_MaxY(This,pVal) ) 

#define IGraficCtl_put_MaxY(This,newVal)	\
    ( (This)->lpVtbl -> put_MaxY(This,newVal) ) 

#define IGraficCtl_get_BackColor(This,pVal)	\
    ( (This)->lpVtbl -> get_BackColor(This,pVal) ) 

#define IGraficCtl_put_BackColor(This,newVal)	\
    ( (This)->lpVtbl -> put_BackColor(This,newVal) ) 

#define IGraficCtl_get_GraficColor(This,pVal)	\
    ( (This)->lpVtbl -> get_GraficColor(This,pVal) ) 

#define IGraficCtl_put_GraficColor(This,newVal)	\
    ( (This)->lpVtbl -> put_GraficColor(This,newVal) ) 

#define IGraficCtl_get_IsLButtonClicked(This,pVal)	\
    ( (This)->lpVtbl -> get_IsLButtonClicked(This,pVal) ) 

#define IGraficCtl_put_IsLButtonClicked(This,newVal)	\
    ( (This)->lpVtbl -> put_IsLButtonClicked(This,newVal) ) 

#define IGraficCtl_get_IsRButtonClicked(This,pVal)	\
    ( (This)->lpVtbl -> get_IsRButtonClicked(This,pVal) ) 

#define IGraficCtl_put_IsRButtonClicked(This,newVal)	\
    ( (This)->lpVtbl -> put_IsRButtonClicked(This,newVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IGraficCtl_INTERFACE_DEFINED__ */



#ifndef __GraficLib_LIBRARY_DEFINED__
#define __GraficLib_LIBRARY_DEFINED__

/* library GraficLib */
/* [version][uuid] */ 


EXTERN_C const IID LIBID_GraficLib;

#ifndef ___IGraficCtlEvents_DISPINTERFACE_DEFINED__
#define ___IGraficCtlEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IGraficCtlEvents */
/* [uuid] */ 


EXTERN_C const IID DIID__IGraficCtlEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("0D2193BD-219B-4057-B8C7-89BF4416C300")
    _IGraficCtlEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IGraficCtlEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _IGraficCtlEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _IGraficCtlEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _IGraficCtlEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _IGraficCtlEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _IGraficCtlEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _IGraficCtlEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _IGraficCtlEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _IGraficCtlEventsVtbl;

    interface _IGraficCtlEvents
    {
        CONST_VTBL struct _IGraficCtlEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IGraficCtlEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define _IGraficCtlEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define _IGraficCtlEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define _IGraficCtlEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define _IGraficCtlEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define _IGraficCtlEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define _IGraficCtlEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IGraficCtlEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_GraficCtl;

#ifdef __cplusplus

class DECLSPEC_UUID("0216D671-F97F-4267-B9B9-4D85FFD43A82")
GraficCtl;
#endif
#endif /* __GraficLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


