// dllmain.h : Declaration of module class.

class CGraficModule : public ATL::CAtlDllModuleT< CGraficModule >
{
public :
	DECLARE_LIBID(LIBID_GraficLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_GRAFIC, "{30365A0D-4D7C-48DD-9B9F-100C2C2199EA}")
};

extern class CGraficModule _AtlModule;
