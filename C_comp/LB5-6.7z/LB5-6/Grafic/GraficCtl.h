// GraficCtl.h : Declaration of the CGraficCtl
#pragma once
#include "resource.h"       // main symbols
#include <atlctl.h>
#include "Grafic_i.h"
#include "_IGraficCtlEvents_CP.h"
#include <math.h>

#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Single-threaded COM objects are not properly supported on Windows CE platform, such as the Windows Mobile platforms that do not include full DCOM support. Define _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA to force ATL to support creating single-thread COM object's and allow use of it's single-threaded COM object implementations. The threading model in your rgs file was set to 'Free' as that is the only threading model supported in non DCOM Windows CE platforms."
#endif

using namespace ATL;



// CGraficCtl
class ATL_NO_VTABLE CGraficCtl :
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<IGraficCtl, &IID_IGraficCtl, &LIBID_GraficLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IOleControlImpl<CGraficCtl>,
	public IOleObjectImpl<CGraficCtl>,
	public IOleInPlaceActiveObjectImpl<CGraficCtl>,
	public IViewObjectExImpl<CGraficCtl>,
	public IOleInPlaceObjectWindowlessImpl<CGraficCtl>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CGraficCtl>,
	public CProxy_IGraficCtlEvents<CGraficCtl>,
	public IQuickActivateImpl<CGraficCtl>,
#ifndef _WIN32_WCE
	public IDataObjectImpl<CGraficCtl>,
#endif
	public IProvideClassInfo2Impl<&CLSID_GraficCtl, &__uuidof(_IGraficCtlEvents), &LIBID_GraficLib>,
	public CComCoClass<CGraficCtl, &CLSID_GraficCtl>,
	public CComControl<CGraficCtl>
{
public:


	CGraficCtl()
	{
		m_nMinX = 1;//������� � ��� ������ �������
		m_nMaxX = 4;
		m_nMinY = -15;//��� � ���� �������
		m_nMaxY = 15;
		m_clrBackColor = RGB(0, 256, 0);
		m_clrGraphColor = RGB(0, 0, 0);
		m_clrGraphColorOld = m_clrGraphColor;
		m_nIsLButtonClicked = 0;
		m_nIsRButtonClicked = 1;
	}

DECLARE_OLEMISC_STATUS(OLEMISC_RECOMPOSEONRESIZE |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_INSIDEOUT |
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST
)

DECLARE_REGISTRY_RESOURCEID(IDR_GRAFICCTL)


BEGIN_COM_MAP(CGraficCtl)
	COM_INTERFACE_ENTRY(IGraficCtl)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(IQuickActivate)
#ifndef _WIN32_WCE
	COM_INTERFACE_ENTRY(IDataObject)
#endif
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CGraficCtl)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY_TYPE("Property Name", dispid, clsid, vtType)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CGraficCtl)
	CONNECTION_POINT_ENTRY(__uuidof(_IGraficCtlEvents))
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CGraficCtl)
	CHAIN_MSG_MAP(CComControl<CGraficCtl>)
	DEFAULT_REFLECTION_HANDLER()
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
	MESSAGE_HANDLER(WM_RBUTTONDOWN, OnRButtonDown)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* const arr[] =
		{
			&IID_IGraficCtl,
		};

		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IGraficCtl
public:
	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		RECT& rc = *(RECT*)di.prcBounds;
		HDC hdc  = di.hdcDraw;

		COLORREF    colBack, colGraph;
		HBRUSH      hOldBrush, hBrush;
		HPEN        hOldPen, hPen;

		// Translate m_clrBackColor, m_clrBackColor  into a COLORREF type
		OleTranslateColor(m_clrBackColor, NULL, &colBack);
		OleTranslateColor(m_clrGraphColor, NULL, &colGraph);

		hPen = (HPEN)GetStockObject(BLACK_PEN);
		hOldPen = (HPEN)SelectObject(hdc, hPen);
		hBrush = (HBRUSH)GetStockObject(WHITE_BRUSH);
		hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);

		// Create and select the brush that will be used to fill the rectangle
		hBrush = CreateSolidBrush(colBack);
		SelectObject(hdc, hBrush);
		Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

		hPen = CreatePen(PS_SOLID, 0, 0);
		SelectObject(hdc, hPen);
		short x0 = rc.left + (rc.right - rc.left) / 2;//�������� ��������������
		short y0 = rc.top + (rc.bottom - rc.top) / 2;

		if (m_nIsLButtonClicked != 0)
		{
		float s = 20;//������� �� ������� � ��������
		hPen = CreatePen(PS_SOLID, 2, colGraph);
		SelectObject(hdc, hPen);
		for (float x = m_nMinX; x <= m_nMaxX; x += 0.3)//0.3=(4-1)/10-10 �����
		{
			MoveToEx(hdc, x*s+x0, y0-(x-5*sin(x)*sin(x))*s, 0);
			float y = (x+0.3)-5*sin((x+0.3))*sin((x+0.3));
			if (y >= m_nMinY && y <= m_nMaxY)
			{
				LineTo(hdc, (x+0.3)*s+x0, y0-y*s);
			}
		}

		SelectObject(hdc, hOldPen);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hPen);
		DeleteObject(hBrush);
		}
		return S_OK;
	}
	short m_nMinX;
	short m_nMaxX;
	short m_nMinY;
	short m_nMaxY;
	OLE_COLOR m_clrBackColor;
	OLE_COLOR m_clrGraphColor;
	OLE_COLOR m_clrGraphColorOld;
	short m_nIsLButtonClicked;
	short m_nIsRButtonClicked;

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}
	STDMETHOD(get_MinX)(SHORT* pVal);
	STDMETHOD(put_MinX)(SHORT newVal);
	STDMETHOD(get_MinY)(SHORT* pVal);
	STDMETHOD(put_MinY)(SHORT newVal);
	STDMETHOD(get_MaxX)(SHORT* pVal);
	STDMETHOD(put_MaxX)(SHORT newVal);
	STDMETHOD(get_MaxY)(SHORT* pVal);
	STDMETHOD(put_MaxY)(SHORT newVal);
	STDMETHOD(get_BackColor)(OLE_COLOR* pVal);
	STDMETHOD(put_BackColor)(OLE_COLOR newVal);
	STDMETHOD(get_GraficColor)(OLE_COLOR* pVal);
	STDMETHOD(put_GraficColor)(OLE_COLOR newVal);
	STDMETHOD(get_IsLButtonClicked)(SHORT* pVal);
	STDMETHOD(put_IsLButtonClicked)(SHORT newVal);
	STDMETHOD(get_IsRButtonClicked)(SHORT* pVal);
	STDMETHOD(put_IsRButtonClicked)(SHORT newVal);
	LRESULT OnLButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnRButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
};

OBJECT_ENTRY_AUTO(__uuidof(GraficCtl), CGraficCtl)
