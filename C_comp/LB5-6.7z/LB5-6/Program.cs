﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MSACAL;

namespace Calendar_client_cSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            //var calendar = new CalendarClass();
            Calendar calendar = new Calendar();
            Console.WriteLine(String.Format("Current value of calendar.Day: {0}", calendar.Day));
            Console.WriteLine(String.Format("Current value of calendar.Year: {0}", calendar.Year));
            Console.WriteLine("Set new day:");
            short newDay = short.Parse(Console.ReadLine());
            calendar.Day = newDay;
            Console.WriteLine("Set new year:");
            short newYear = short.Parse(Console.ReadLine());
            calendar.Year = newYear;
            Console.WriteLine(String.Format("New value of calendar.Day: {0}", calendar.Day));
            Console.WriteLine(String.Format("New value of calendar.Year: {0}", calendar.Year));
            Console.ReadLine();
        }
    }
}
