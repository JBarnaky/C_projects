#include <Windows.h>
#include <tchar.h>
#include <stdio.h>
#include <InitGuid.h>
int main()
{	
	printf("Initialize - MSCAL.Calendar.15\n");
	HRESULT hr = OleInitialize(NULL);

	// Get the CLSID for the application.
	wchar_t progid[] = L"MSCAL.Calendar.15";
	CLSID clsid;
	hr = ::CLSIDFromProgID(progid, &clsid);
	// Create the component.
	IDispatch* pIDispatch = NULL;
	hr = ::CoCreateInstance(clsid, NULL, CLSCTX_INPROC_SERVER, IID_IDispatch, (void**)&pIDispatch);

	//����� �������
	DISPID dispidDay, dispidMonth,dispidYear;
	OLECHAR* nameDay = L"Day";
	OLECHAR* nameMonth = L"Month";
	OLECHAR* nameYear = L"Year";

	DISPPARAMS dispparams = { NULL, NULL, 0, 0 };
	DISPID Put = DISPID_PROPERTYPUT;
	//-------PROPERTYGET---------
	VARIANT Result;
	VariantInit(&Result);
	printf("Current Date ");
	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameDay, 1, GetUserDefaultLCID(), &dispidDay);
	hr = pIDispatch->Invoke(dispidDay, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYGET, &dispparams, &Result, NULL, NULL);
	printf(" %d", Result.iVal);

	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameMonth, 1, GetUserDefaultLCID(), &dispidMonth);
	hr = pIDispatch->Invoke(dispidMonth, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYGET, &dispparams, &Result, NULL, NULL);
	printf("/%d/", Result.iVal);

	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameYear, 1, GetUserDefaultLCID(), &dispidYear);
	hr = pIDispatch->Invoke(dispidYear, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYGET, &dispparams, &Result, NULL, NULL);
	printf("%d ", Result.iVal);
	//------END of PROPERTYGET----------

	//----��������� ����� �������� ��� � ������
	int d = 0,m = 0;
	
	printf("Set new Year:");
	scanf("%d", &m);
	printf("\nSet new day:");
	scanf("%d", &d);

	VARIANTARG argsDay;//����
	VariantInit(&argsDay);
	argsDay.vt = VT_I2;
	argsDay.iVal = d;

	VARIANTARG argsYear;//���
	VariantInit(&argsYear);
	argsYear.vt = VT_I2;
	argsYear.iVal = m;

	DISPPARAMS dispparamsDay = { &argsDay, &Put, 1, 1 };
	DISPPARAMS dispparamsYear = { &argsYear, &Put, 1, 1 };

	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameDay, 1, GetUserDefaultLCID(), &dispidDay);
	hr = pIDispatch->Invoke(dispidDay, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYPUT, &dispparamsDay, &Result, NULL, NULL);
	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameYear, 1, GetUserDefaultLCID(), &dispidYear);
	hr = pIDispatch->Invoke(dispidYear, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYPUT, &dispparamsYear, &Result, NULL, NULL);

	printf("New Date  ");
	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameDay, 1, GetUserDefaultLCID(), &dispidDay);
	hr = pIDispatch->Invoke(dispidDay, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYGET, &dispparams, &Result, NULL, NULL);
	printf(" %d", Result.iVal);
	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameMonth, 1, GetUserDefaultLCID(), &dispidMonth);
	hr = pIDispatch->Invoke(dispidMonth, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYGET, &dispparams, &Result, NULL, NULL);
	printf("/%d/", Result.iVal);
	hr = pIDispatch->GetIDsOfNames(IID_NULL, &nameYear, 1, GetUserDefaultLCID(), &dispidYear);
	hr = pIDispatch->Invoke(dispidYear, IID_NULL, GetUserDefaultLCID(), DISPATCH_PROPERTYGET, &dispparams, &Result, NULL, NULL);
	printf("%d ", Result.iVal);

	if (FAILED(hr))
	{
		printf("\nInvoke call failed.", hr);
		pIDispatch->Release();
		return 1;
	}
	pIDispatch->Release();
	system("Pause");
}