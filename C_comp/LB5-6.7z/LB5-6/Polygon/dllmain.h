// dllmain.h : Declaration of module class.

class CPolygonModule : public CAtlDllModuleT< CPolygonModule >
{
public :
	DECLARE_LIBID(LIBID_PolygonLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_POLYGON, "{6D5923A4-8854-409C-9139-C52032B4B3D8}")
};

extern class CPolygonModule _AtlModule;
